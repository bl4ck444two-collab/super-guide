tag @s add an.ghosted_rider
summon minecraft:skeleton_horse ~ ~ ~ {Tags:["an.ghosted_horse_temp"]}
ride @n[tag=an.ghosted_rider] mount @n[tag=an.ghosted_horse_temp]