data modify entity @s Health set value 36f
data modify entity @s DeathLootTable set value "an:entities/red_fortress/king_wither_skeleton"
data modify entity @s PersistenceRequired set value true

attribute @s minecraft:max_health base set 36

item replace entity @s weapon.mainhand with minecraft:stone_sword
item replace entity @s armor.head with minecraft:player_head[minecraft:profile={properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYTMxMzkyMGJkYWIwZmFhMTI4OTk5MjE5NWRjNjRhMjE0OTA5OGIxNTNjMzVjNmJhZTc2NWJhM2IwODQyZDFhOSJ9fX0="}]}]
item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:trim={material:"minecraft:redstone",pattern:"minecraft:sentry"}]

data modify entity @s drop_chances.mainhand set value 0
data modify entity @s drop_chances.head set value 0
data modify entity @s drop_chances.chest set value 0

tag @s remove an.king_wither_skeleton_temp
tag @s add an.king_wither_skeleton