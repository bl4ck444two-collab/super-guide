data modify entity @s Health set value 24f
data modify entity @s Brain.memories."minecraft:admiring_disabled".value set value true
data modify entity @s DeathLootTable set value "an:entities/misc/piglin_rider"
data modify entity @s CannotHunt set value true

attribute @s minecraft:max_health base set 24

item replace entity @s weapon.mainhand with minecraft:crossbow[minecraft:enchantments={"minecraft:quick_charge":1}]
item replace entity @s armor.head with minecraft:golden_helmet[minecraft:trim={material:"minecraft:netherite",pattern:"minecraft:silence"}]
item replace entity @s armor.legs with minecraft:netherite_leggings[minecraft:trim={material:"minecraft:gold",pattern:"minecraft:snout"}]

data modify entity @s drop_chances.mainhand set value 0
data modify entity @s drop_chances.head set value 0
data modify entity @s drop_chances.legs set value 0

tag @s remove an.piglin_rider_temp
tag @s add an.piglin_rider