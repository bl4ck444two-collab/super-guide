summon minecraft:piglin ~ ~ ~ {Tags:["an.piglin_rider_temp"]}
ride @n[tag=an.piglin_rider_temp] mount @n[tag=an.hoglin_jockey]