kill @s
execute if block ~ ~-1 ~ minecraft:soul_soil run place feature an:10_vegetal_decoration/selector/heap_bonemeal_fungi
execute if block ~ ~-1 ~ minecraft:soul_soil if block ~ ~0.1 ~ #an:generic/heap_block run playsound minecraft:item.bone_meal.use block @a ~ ~ ~
execute if block ~ ~-1 ~ minecraft:soul_soil if block ~ ~0.1 ~ #an:generic/heap_block run particle minecraft:mycelium ~ ~ ~ 0.7 0.7 0.7 0 50 normal
execute if block ~ ~-1 ~ minecraft:soul_soil if block ~ ~0.1 ~ #an:generic/heap_block run particle minecraft:happy_villager ~ ~ ~ 0.5 0.5 0.5 0 10 normal