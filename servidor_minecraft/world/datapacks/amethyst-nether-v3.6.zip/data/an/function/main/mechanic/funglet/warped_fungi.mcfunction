kill @s
execute if block ~ ~-1 ~ #an:generic/nylium_block run place feature an:10_vegetal_decoration/selector/warped_bonemeal_fungi
execute if block ~ ~-1 ~ minecraft:netherrack if block ~ ~0.1 ~ minecraft:warped_hyphae run playsound minecraft:item.bone_meal.use block @a ~ ~ ~
execute if block ~ ~-1 ~ minecraft:netherrack if block ~ ~0.1 ~ minecraft:warped_hyphae run particle minecraft:warped_spore ~ ~ ~ 0.7 0.7 0.7 0 50 normal
execute if block ~ ~-1 ~ minecraft:netherrack if block ~ ~0.1 ~ minecraft:warped_hyphae run particle minecraft:happy_villager ~ ~ ~ 0.5 0.5 0.5 0 10 normal