data modify entity @s Age set value 0
data modify entity @s CannotBeHunted set value true

tag @s add an.hoglin_jockey

execute at @s run function an:main/util/spawn/piglin_rider