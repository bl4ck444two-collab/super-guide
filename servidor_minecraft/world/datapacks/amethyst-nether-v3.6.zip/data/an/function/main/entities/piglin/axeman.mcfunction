data modify entity @s Health set value 56f
data modify entity @s DeathLootTable set value "an:entities/grand_bastion/axeman"
data modify entity @s PersistenceRequired set value true

attribute @s minecraft:max_health base set 56

item replace entity @s weapon.mainhand with minecraft:golden_axe
item replace entity @s weapon.offhand with minecraft:shield[minecraft:banner_patterns=[{color:"black",pattern:"minecraft:base"},{color:"yellow",pattern:"minecraft:stripe_center"},{color:"black",pattern:"minecraft:flower"},{color:"yellow",pattern:"minecraft:stripe_middle"},{color:"black",pattern:"minecraft:straight_cross"},{color:"yellow",pattern:"minecraft:curly_border"},{color:"black",pattern:"minecraft:border"}]]
item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:trim={material:"minecraft:gold",pattern:"minecraft:ward"}]

data modify entity @s drop_chances.mainhand set value 0
data modify entity @s drop_chances.offhand set value 0
data modify entity @s drop_chances.chest set value 0

tag @s remove an.piglin_axeman_temp
tag @s add an.piglin_axeman