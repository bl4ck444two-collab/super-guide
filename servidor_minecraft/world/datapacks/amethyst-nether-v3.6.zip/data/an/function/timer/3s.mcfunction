schedule function an:timer/3s 3s append

### util
execute at @e[tag=an.ghosted_entities,predicate=an:biome/soul_sand_valley] run function an:main/util/visual/on_flames
execute at @e[tag=an.sporeback,predicate=an:biome/wart_heap] run function an:main/util/visual/on_spores