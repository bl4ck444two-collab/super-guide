kill @s
particle minecraft:flame ~ ~ ~ 0 0 0 0.25 30 force
particle minecraft:smoke ~ ~ ~ 0 0 0 0.25 30 force
summon minecraft:tnt ~ ~ ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}