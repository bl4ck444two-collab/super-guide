data modify entity @s Health set value 24f
data modify entity @s Brain.memories."minecraft:admiring_disabled".value set value true
data modify entity @s DeathLootTable set value "an:entities/grand_bastion/swordsman"
data modify entity @s PersistenceRequired set value true
data modify entity @s CannotHunt set value true

attribute @s minecraft:max_health base set 24

item replace entity @s weapon.mainhand with minecraft:golden_sword
item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:trim={material:"minecraft:gold",pattern:"minecraft:ward"}]

data modify entity @s drop_chances.mainhand set value 0
data modify entity @s drop_chances.chest set value 0

tag @s remove an.piglin_swordsman_temp
tag @s add an.piglin_swordsman