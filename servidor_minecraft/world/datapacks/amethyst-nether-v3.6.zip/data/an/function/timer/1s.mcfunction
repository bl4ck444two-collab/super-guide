schedule function an:timer/1s 1s append

### entities
execute as @e[type=#an:tagged] run function an:main/entities/sort_entity

### undead
execute as @e[type=#an:piglins,predicate=an:biome/wart_heap] run function an:main/mechanic/undead/add_weakness
execute as @e[type=zombified_piglin,tag=an.sporeback] unless data entity @s angry_at at @s run function an:main/mechanic/undead/attack_piglin
execute as @e[type=zombified_piglin,tag=an.sporeback] unless data entity @s angry_at at @s run function an:main/mechanic/undead/attack_player

### util
execute as @e[type=minecraft:piglin,tag=an.piglin_rider] at @s run function an:main/util/randomization/piglin_weapon
execute as @e[type=minecraft:skeleton,tag=an.ghosted_rider] at @s run function an:main/util/randomization/ghosted_weapon