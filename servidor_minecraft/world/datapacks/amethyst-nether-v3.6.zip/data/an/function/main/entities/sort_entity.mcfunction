### biome specific mob
execute if entity @s[type=minecraft:zombified_piglin,tag=!an.sorted,predicate=an:biome/wart_heap,predicate=an:randomization/0.25] run return run function an:main/entities/piglin/sporeback
execute if entity @s[type=minecraft:skeleton,tag=!an.sorted,tag=!an.skeleton_variants,predicate=an:biome/soul_sand_valley,predicate=an:randomization/0.125] run return run function an:main/entities/skeleton/ghosted
execute if entity @s[type=minecraft:skeleton,tag=!an.sorted,tag=!an.skeleton_variants,predicate=an:biome/black_peaks,predicate=an:randomization/0.25] run return run function an:main/entities/skeleton/skeletal_piglin

### jockey
execute if entity @s[tag=an.ghosted_horse_temp] run return run function an:main/entities/jockey/ghosted_horse_jockey
execute if entity @s[type=minecraft:hoglin,tag=!an.sorted,predicate=an:biome/is_crimson,predicate=an:randomization/0.025] run return run function an:main/entities/jockey/hoglin_jockey

### piglin
execute if entity @s[tag=an.piglin_axeman_temp] run return run function an:main/entities/piglin/axeman
execute if entity @s[tag=an.piglin_crossbowman_temp] run return run function an:main/entities/piglin/crossbowman
execute if entity @s[tag=an.piglin_rider_temp] run return run function an:main/entities/piglin/rider
execute if entity @s[tag=an.sporeback_temp] run return run function an:main/entities/piglin/sporeback
execute if entity @s[tag=an.piglin_swordsman_temp] run return run function an:main/entities/piglin/swordsman

### skeleton
execute if entity @s[tag=an.ghosted_temp] run return run function an:main/entities/skeleton/ghosted
execute if entity @s[tag=an.king_wither_skeleton_temp] run return run function an:main/entities/skeleton/king_wither_skeleton
execute if entity @s[tag=an.skeletal_piglin_temp] run return run function an:main/entities/skeleton/skeletal_piglin

tag @s add an.sorted