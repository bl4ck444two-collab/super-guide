### bomb
execute as @e[type=minecraft:snowball,tag=!bomb_loaded,predicate=an:misc/is_bomb] at @s run function an:main/mechanic/bomb/add_marker
execute as @e[type=minecraft:marker,tag=bomb_marker] unless predicate an:misc/is_riding at @s run function an:main/mechanic/bomb/is_explosion

### funglet
execute as @e[type=minecraft:marker,tag=an.funglet] run function an:main/mechanic/funglet/sort_funglet

### misc
execute as @e[type=minecraft:ender_pearl,predicate=an:biome/is_nether] at @s run function an:main/mechanic/no_above_roof