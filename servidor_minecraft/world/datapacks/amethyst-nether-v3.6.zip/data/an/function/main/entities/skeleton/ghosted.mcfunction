data modify entity @s Health set value 24f
data modify entity @s DeathLootTable set value "an:entities/misc/ghosted"

attribute @s minecraft:max_health base set 24
attribute @s minecraft:movement_efficiency base set 1
attribute @s minecraft:burning_time base set -1

effect give @s minecraft:fire_resistance infinite 0 true

item replace entity @s weapon.mainhand with minecraft:stone_sword[minecraft:enchantments={"minecraft:fire_aspect":1}]
item replace entity @s armor.head with minecraft:player_head[minecraft:profile={properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNTRlNWEyMzIxZTYzOWZkYzlkNDI0MzRhZmYzZDdjNjc0YjRhODhiMmU0NWVkOWYwMzcyM2JlZmVjYzlhM2U3YyJ9fX0="}]}]
item replace entity @s armor.chest with minecraft:chainmail_chestplate[minecraft:trim={material:"minecraft:diamond",pattern:"minecraft:rib"}]

data modify entity @s drop_chances.mainhand set value 0
data modify entity @s drop_chances.head set value 0
data modify entity @s drop_chances.chest set value 0

tag @s remove an.ghosted_temp
tag @s add an.ghosted
tag @s add an.ghosted_entities
tag @s add an.skeleton_variants

execute if predicate an:randomization/0.05 at @s run function an:main/util/spawn/ghosted_horse