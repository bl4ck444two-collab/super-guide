execute if entity @s[tag=an.crimson_funglet] at @s run function an:main/mechanic/funglet/crimson_fungi
execute if entity @s[tag=an.heap_funglet] at @s run function an:main/mechanic/funglet/heap_fungi
execute if entity @s[tag=an.warped_funglet] at @s run function an:main/mechanic/funglet/warped_fungi