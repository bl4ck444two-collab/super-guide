execute if block ~ ~1 ~ minecraft:bedrock run playsound minecraft:entity.ender_eye.death block @a ~ ~ ~
execute if block ~ ~1 ~ minecraft:bedrock run particle minecraft:dragon_breath ~ ~ ~ 0.3 0.3 0.3 0.2 15 normal
execute if block ~ ~1 ~ minecraft:bedrock run kill @s