data modify entity @s Health set value 28f
data modify entity @s DeathLootTable set value "an:entities/misc/sporeback"

attribute @s minecraft:max_health base set 28
attribute @s minecraft:movement_speed base set 0.25
attribute @s minecraft:scale base set 0.9

effect give @s minecraft:regeneration infinite 0 true

item replace entity @s weapon.mainhand with minecraft:stone_sword
item replace entity @s armor.head with minecraft:player_head[minecraft:profile={properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjQ5YmU3MGY4ODBkM2M3NzljNjBiMDUzNzBiNmMxOTQwZjM1NzJkNWUyYTUyN2NlOWU3NjE5ZmIxMjUzMDhjOSJ9fX0="}]}]
item replace entity @s armor.legs with minecraft:leather_leggings[minecraft:dyed_color=4266025,minecraft:trim={material:"minecraft:quartz",pattern:"minecraft:rib"}]

data modify entity @s drop_chances.mainhand set value 0
data modify entity @s drop_chances.head set value 0
data modify entity @s drop_chances.legs set value 0

tag @s add an.sporeback
tag @s remove an.sporeback_temp

execute run function an:main/util/randomization/sporeback_weapon