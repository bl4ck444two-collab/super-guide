data modify entity @s Health set value 20f
data modify entity @s DeathLootTable set value "an:entities/misc/skeletal_piglin"

attribute @s minecraft:max_health base set 20

item replace entity @s weapon.mainhand with minecraft:golden_pickaxe
item replace entity @s armor.head with minecraft:player_head[minecraft:profile={properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDgxNjA0OTRkMmNiZjRlYWQ3ZmRkZTE1MmU2Y2YzM2I3NjU3ZDhjZWZkZjU5YmVkZDFiOWRhNDhkNzVkZWRjIn19fQ=="}]}]
item replace entity @s armor.chest with minecraft:leather_chestplate[minecraft:trim={material:"minecraft:gold",pattern:"minecraft:shaper"}]

data modify entity @s drop_chances.mainhand set value 0
data modify entity @s drop_chances.head set value 0
data modify entity @s drop_chances.chest set value 0

tag @s remove an.skeletal_piglin_temp
tag @s add an.skeletal_piglin
tag @s add an.skeleton_variants