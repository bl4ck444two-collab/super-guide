execute if predicate an:randomization/0.125 at @s run return run item replace entity @s weapon.mainhand with minecraft:air
execute if predicate an:randomization/0.125 at @s run return run item replace entity @s weapon.mainhand with minecraft:brown_mushroom
execute if predicate an:randomization/0.125 at @s run return run item replace entity @s weapon.mainhand with minecraft:red_mushroom
execute if predicate an:randomization/0.25 at @s run return run item replace entity @s weapon.mainhand with minecraft:rotten_flesh
execute if predicate an:randomization/0.25 at @s run return run item replace entity @s weapon.mainhand with minecraft:stone_spear