data modify entity @s PersistenceRequired set value false
data modify entity @s SkeletonTrap set value false

attribute @s minecraft:movement_efficiency base set 1
attribute @s minecraft:burning_time base set -1

effect give @s minecraft:fire_resistance infinite 0 true

tag @s remove an.ghosted_horse_temp
tag @s add an.ghosted_horse
tag @s add an.ghosted_entities