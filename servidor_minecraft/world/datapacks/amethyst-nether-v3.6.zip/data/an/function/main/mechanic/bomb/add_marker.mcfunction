tag @s add bomb_loaded
summon minecraft:marker ~ ~ ~ {Tags:["bomb_marker"]}
ride @n[tag=bomb_marker] mount @s